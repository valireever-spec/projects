# Claude Context — The Ignored Signal

You are helping build **The Ignored Signal**, an anonymous multilingual short-form news platform covering underreported European stories.

## Brand
- 🇬🇧 The Ignored Signal
- 🇫🇷 Le Signal Ignoré
- 🇩🇪 Das Überhörte Signal
- 🇮🇹 Il Segnale Ignorato
- 🇷🇴 Semnalul Ignorat

## Mission
Surface real European stories that were reported but ignored — factual, sourced, neutral. Tone: a trusted friend explaining something important. Never opinionated, never speculative, always sourced.

## Tech Stack
- React (JSX) frontend
- Anthropic Claude API (`claude-sonnet-4-20250514`)
- Custom CSS variables, no framework

## Key Rules
- One language per video, one platform per video
- Minimum two sources per story, at least one primary
- Sources shown on screen in every video
- No opinion, no speculation, no unverified claims
- Full creator anonymity (ProtonMail + VoIP + Mullvad VPN + AI voice)
- No monetization at launch — Estonian OÜ added later

## Content Categories
EU legislation, economic stories, environmental findings, scientific research, historical context, human interest, Russia hybrid war, human rights violations, corruption

## Platform
YouTube Shorts + TikTok — 5 languages × 2 platforms = 10 accounts total

## What to build
A React + Claude API platform with:
1. Story Finder — surface underreported European stories by category/language
2. Script Generator — friend-tone narration script per language with source citations
3. Visibility Advisor — score content for SEO, hook, algorithm fit, source transparency
4. Content Calendar — plan across 5 languages and 2 platforms
5. Export — production-ready script with timestamps

## This project is completely separate from all other projects. No shared code, identity, or infrastructure.

## Full brief: See PROJECT_BRIEF.md
