# The Ignored Signal — Claude Code Instructions

This is the development workspace for **The Ignored Signal** multilingual news platform.

## Project context
Read `PROJECT_BRIEF.md` for full context before making any changes.
Read `CLAUDE_CONTEXT.md` for a quick session summary.

## Stack
- React JSX (single file components where possible)
- Anthropic Claude API (`claude-sonnet-4-20250514`, max_tokens: 1000)
- Custom CSS-in-JS via style tags (no Tailwind, no external CSS framework)
- No browser storage APIs (use React state)

## Code standards
- All API calls wrapped in try/catch
- JSON responses: strip markdown fences before parsing
- Loading states on all async operations
- Error messages shown inline, never silent failures
- Mobile responsive — max-width 700px centered layout
- Dark theme by default — background `#09090f`

## File structure (to build)
```
src/
  components/
    StoryFinder.jsx       # Search and surface underreported stories
    ScriptGenerator.jsx   # Friend-tone script per language
    VisibilityAdvisor.jsx # Score content for reach and trust
    ContentCalendar.jsx   # Plan across 5 languages × 2 platforms
    ExportPanel.jsx       # Production-ready script with timestamps
  App.jsx                 # Main tabbed layout
  index.jsx               # Entry point
```

## Design tokens
```css
--bg: #09090f
--card: #0e0e18
--border: #1b1b2a
--fg: #e9e5da
--muted: #636077
--accent: #c0392b        /* deep red */
--accent-alt: #1a6bb5    /* electric blue */
--emerald: #27ae78
--display: 'Playfair Display', serif
--body: 'Lato', sans-serif
--mono: 'Fira Code', monospace
```

## Languages supported
en (English), fr (French), de (German), it (Italian), ro (Romanian)

## Important
This project is completely isolated from all other projects.
No shared code, no shared accounts, no cross-references.
